class PdfTagLibTests extends GroovyTestCase {

    void testSomething() {

    }
}
